//
//  NewOccasionTableViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/30/21.
//

import UIKit

class NewOccasionTableViewCell: UITableViewCell {

    @IBOutlet weak var myView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        myView.layer.cornerRadius=10
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
