//
//  OccasionTableViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/30/21.
//

import UIKit

class OccasionTableViewCell: UITableViewCell {

    @IBOutlet weak var btn2: UIView!
    @IBOutlet weak var btn1: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        view1.layer.cornerRadius = 10
        view2.layer.cornerRadius = 10
        btn2.layer.cornerRadius = 10
        btn1.layer.cornerRadius = 10
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
