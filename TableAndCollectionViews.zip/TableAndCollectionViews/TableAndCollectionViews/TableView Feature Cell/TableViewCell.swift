//
//  TableViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/28/21.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var myPageController: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var currentPage = 0

    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.delegate = self
        collectionView.dataSource = self
        self.myPageController.numberOfPages = 3

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        


    }
    
}

extension TableViewCell: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIScrollViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.register(CollectionViewCell.self, indexPath: indexPath)
        if(indexPath.row == 0)
        {
            cell.myImage.image =  UIImage(named: "1")
            return cell
        }
        else if (indexPath.row == 1)
        {
            cell.myImage.image =  UIImage(named: "2")
            return cell
        }
        else{
            cell.myImage.image =  UIImage(named: "3")
            return cell
        }
    }
    

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       let width = ((collectionView.frame.width - 5) / 1) // 15 because of paddings
       print("cell width : \(width)")
       return CGSize(width: width, height: 100)
   }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pageWidth = scrollView.frame.width
        self.currentPage = Int((scrollView.contentOffset.x + pageWidth / 2) / pageWidth)
        self.myPageController.currentPage = self.currentPage
    }
}
