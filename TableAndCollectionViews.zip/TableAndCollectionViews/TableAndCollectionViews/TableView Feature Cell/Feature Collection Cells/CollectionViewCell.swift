//
//  CollectionViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/28/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var myImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
