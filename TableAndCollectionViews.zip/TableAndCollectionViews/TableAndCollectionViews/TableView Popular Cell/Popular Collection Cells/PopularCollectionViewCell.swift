//
//  PopularCollectionViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/30/21.
//

import UIKit

class PopularCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
