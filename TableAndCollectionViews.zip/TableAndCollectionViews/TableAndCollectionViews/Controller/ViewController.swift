//
//  ViewController.swift
//  ShahrukhUI
//
//  Created by Apple on 6/28/21.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var tableView: UITableView!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate=self
        tableView.dataSource=self
        tableView.rowHeight = UITableView.automaticDimension

    }
}




extension ViewController: UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if(indexPath.row == 0)
        {
            let cell = tableView.register(TableViewCell.self, indexPath: indexPath)
            return cell
        }
        
        else if(indexPath.row == 1)
        {
            let cell = tableView.register(CategoryTableViewCell.self, indexPath: indexPath)
            return cell
        }
        
        else if(indexPath.row == 2)
        {
            let cell = tableView.register(PopularTableViewCell.self, indexPath: indexPath)
            return cell
        }
        
        else if(indexPath.row == 3)
        {
            let cell = tableView.register(OccasionTableViewCell.self, indexPath: indexPath)
            return cell
        }
        else
        {
            let cell = tableView.register(NewOccasionTableViewCell.self, indexPath: indexPath)
            return cell
        }

    }
}
