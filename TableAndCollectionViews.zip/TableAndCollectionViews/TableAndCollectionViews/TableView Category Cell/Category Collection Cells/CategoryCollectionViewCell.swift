//
//  CategoryCollectionViewCell.swift
//  ShahrukhUI
//
//  Created by Apple on 6/29/21.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
